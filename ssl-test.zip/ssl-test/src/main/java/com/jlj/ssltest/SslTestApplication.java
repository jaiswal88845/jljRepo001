package com.jlj.ssltest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SslTestApplication {

	public static void main(String[] args) {
		SpringApplication.run(SslTestApplication.class, args);
	}

}
