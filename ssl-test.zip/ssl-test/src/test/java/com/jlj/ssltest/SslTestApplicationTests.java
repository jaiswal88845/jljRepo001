package com.jlj.ssltest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SslTestApplicationTests {

	@Test
	void contextLoads() {
	}

}
